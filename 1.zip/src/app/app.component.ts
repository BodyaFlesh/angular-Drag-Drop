import { Component } from '@angular/core';
import {CdkDragDrop, moveItemInArray, transferArrayItem} from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  todo = [
    {
      title:  'cat 1',
      img:    '/assets/images/cat-1.jpg',
      tag:    'tag 1',
    },
    {
      title:  'cat 2',
      img:    '/assets/images/cat-2.jpg',
      tag:    'tag 1',
    },
    {
      title:  'cat 3',
      img:    '/assets/images/cat-3.jpg',
      tag:    'tag 1',
    },
    {
      title:  'cat 4',
      img:    '/assets/images/cat-4.jpg',
      tag:    'tag 2',
    },
    {
      title:  'cat 5',
      img:    '/assets/images/cat-5.jpg',
      tag:    'tag 2',
    },
    {
      title:  'cat 7',
      img:    '/assets/images/cat-3.jpg',
      tag:    'tag 2',
    },
    {
      title:  'cat 8',
      img:    '/assets/images/cat-3.jpg',
      tag:    'tag 2',
    },
    {
      title:  'cat 9',
      img:    '/assets/images/cat-1.jpg',
      tag:    'tag 2',
    },
    {
      title:  'cat 10',
      img:    '/assets/images/cat-4.jpg',
      tag:    'tag 2',
    }
  ];

  done = [
    {
      title:  'cat 6',
      img:    '/assets/images/cat-6.jpg',
      tag:    'tag 3'
    }
  ];

  drop(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data,
                        event.container.data,
                        event.previousIndex,
                        event.currentIndex);
    }
  }
}
